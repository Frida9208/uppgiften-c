﻿using System.Security.Cryptography.X509Certificates;

namespace Tests.Services;

public class FileService_Tests
{
  
    [Fact]
    public void SaveContentToFile_ShouldSaveContentToAFile()
    {
        //arrange
        var content = "test";
        var filename = $"{Guid.NewGuid().ToString()}.json";
        File.WriteAllText{filename,content};

        IFileService fileService = new FileService(filename);
        fileService.SaveContentToFile();
        bool IFileService.SaveContentToFile(content);
      

        try
        { 

        //act
        var result = fileService.GetContentFromFile();

        //assert
        Assert.Equal(content , result);
    }
        finally {
            if (File.Exists(filename)
                File.Delete(filename);
}


        [Fact]
        {
            public void GetContentFromFile_ShouldreturnContentFromFile()
    {

    }

        }
