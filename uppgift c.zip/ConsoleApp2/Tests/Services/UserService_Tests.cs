﻿using System.Text.Json;

namespace Tests.Services;

public class UserService_Tests
{
    private Mock<IFileService> _fileServiceMock;
    private readonly IUserService _userService;

    public UserService_Tests()
    {
        _fileServiceMock = new Mock<IfileService>();
        _userService = new UserService_Tests(_fileServiceMock.Object);
    }
    [Fact]
    public void Save_ShouldReturnTrue_AddSaveUserToListAndSaveToFile()
    {
        //arrange
        var userRegistrationForm = new UserRegistrationForm()
        {
            FirstName = "John"
            LastName = "Doe"
            Email = "john.doe@domain.com"

        };

        _fileServiceMock.Setup(X => X.SaveContentToFile(It.IsAny<string>)).Returns(true);

        //act
        var result = _userService.Save(userRegistrationForm);


        //assert
        Assert.True(result);
        _fileServiceMock.Verify(X => X.SaveContentToFile(It.IsAny<string>)),Times.Once ;
    }

    [Fact]
    public void GetAll_ShouldReturnListOfUsers()
    {
        //arrange
      List<User> expected = [ new User {Id = "1"FirstName = "John" LastName = "Doe",Email = "john.doe@domain.com" }]
      var json = JsonSerializer.Serialize(expected);

        
            
        _fileServiceMock.Setup(X => X.GetContentFromFile()).returns(json);

        //act
        var result = _userService.GetAll();
        

        //assert
        Assert.NotNull(result);
        Assert.Single(result);
        Assert.Equal(expected[0].Id, result.First().Id);
        Assert.Equal(expected[0].FirstName, result.First().FirstName);
        Assert.Equal(expected[0].LastName, result.First().LastName);
        Assert.Equal(expected[0].Email, result.First().Email);
    }
}
