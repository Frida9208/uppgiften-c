﻿using System.Runtime.ExceptionServices;
using ConsoleApp2.Interfaces;

namespace presentation.Dialogs Dialogs;


    public class MenuDialogs [IUserService userService]

    {
    private readonly iuserservice _userservice = userservice;

public void MainMenu()

{
    while (true)

        Console.Clear();
    Console.WriteLine("--menu options--");
    Console.WriteLine("1. Add user";
    Console.WriteLine("2. View All Users");
    Console.WriteLine();
    Console.WriteLine("Select Option");
    var option = Console.ReadLine();

    switch (option)

    {
        case "1":
            AddUserOption()
            break;
        case "2":
            ViewAllUsersOption()
            break;
    }
}
}

public void AddUserOption(Console.writeLine()

    var form = UserFactory.create();

Console.Clear();
Console.WriteLine("--New User--");
Console.WriteLine("First Name";
Forma.FirstName = Console.ReadLine()!;
Console.WriteLine("Last Name");
form.LastName = Console.ReadLine()!;
Console.WriteLine("Email");
Form.email = Console.ReadLine()!;
Console.WriteLine("telefonnummer");
Form.telefonnummer = Console.ReadLine()!;
Console.WriteLine("gatuadress");
Form.gatuadress = Console.ReadLine()!;
Console.WriteLine("postnummer");
Form.postnummer = Console.ReadLine()!;
Console.WriteLine("ort");
Form.ort = Console.ReadLine()!;

var result = _userService.Save(form);
if (result)
    Console.WriteLine("användare var skapad");

else

{
    Console.WriteLine("Användare missslyckades att skapas");

    Console.ReadKey();
    {

    }

public void ViewAllUsersOption()

    Console.Clear();
Console.WriteLine("2. View All Users");

var users = _usersService.GetAll();
foreach (var user in users)
    Console.WriteLine($"{user.FirstName}, {user.LastName}, {user.email}, {user.telefonnummer}, {user.gatuadress}, {user.postnummer},{user.Ort}");