using ConsoleApp2.Interfaces;
using ConsoleApp2.Services;
using Microsoft.Extensions.DependencyInjektion;
using presentation.Dialogs;
var ServiceCollection = new ServiceCollection();
ServiceCollection.AddSingleton<IFileService>(new FileService("users.json");
ServiceCollection.Addsingleton<iuserservice, userservice>();
ServiceCollection Addsingleton<Menudialogs>();

var serviceProvider = ServiceCollection.BuildServiceProvider();
var menudialogs = serviceProvider.GetRequiredService<MenuDialogs>();

menudialogs.MainMenu();




{
}