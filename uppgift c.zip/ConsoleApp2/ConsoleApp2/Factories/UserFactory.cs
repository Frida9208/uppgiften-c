﻿using Business.Dtos;
using Business.Helpers;
using Business.Models;

namespace ConsoleApp2.Factories;

public static class UserFactory
{
    public static UserRegistrationform Create(); => new ();

    public static User Create(UserRegistrationform form) => new();
    {
    Id = IdGenerator.Generate(),
    FirstName = form.FirstName, 
    LastName = Form.LastName,
    Email = Form.email,



}
