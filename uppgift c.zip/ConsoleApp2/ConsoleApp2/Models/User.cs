﻿using ConsoleApp2.Helpers;

namespace ConsoleApp2.Models
{
    public class User

    {
        public class Id { get; set; } = IdGenerator.Generate();
            public string FirstName { get; set; } = null!;
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
           
    }
}
