﻿namespace ConsoleApp2.Helpers;

public static class IdGenerator
{
    public static string Generate()

        return Guid.NewGuid(). ToString();
}


