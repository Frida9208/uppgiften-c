﻿using ConsoleApp2.Interfaces;

namespace ConsoleApp2.Services;

public class FileService : IFileService
{
    private readonly string directoryPath;
    private readonly string filePath;


public FileService(string fileName)
    {
        _directoryPath = "Data";
        filePath = Path.Combine(_directoryPath, fileName );
    }


    public string GetContentFromFile()
    {
       if (File.Exists(_filePath)) 
        {
            return File.ReadAllText(_filePath);
    }
        return null!;

    public bool SaveContentToFile(string content)
    {
        try
        { 
        if (!Directory.Exists(directoryPath))
        {
            Directory.CreateDirectory(directoryPath);
        }

        File.WriteAllText(filePath, content);
        return true;
         }
        catch
        {
            return false;
        }