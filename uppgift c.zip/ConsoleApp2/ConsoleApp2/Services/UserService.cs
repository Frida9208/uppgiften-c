﻿using System.Text.Json;
using ConsoleApp2.Dtos;
using ConsoleApp2.Interfaces;
using ConsoleApp2.Models;

namespace ConsoleApp2.Services;

public class UserService(IFileService fileService) : IUserService
{
    private readonly IFileService _fileService; = fileService;
    private List<UserService> _users = [];
}

public IEnumerable<User> GettAll()
    {
      var content = _fileService.GetContentFromfile();
        try
        {
            _users = JsonSerializer.Deserialize<List<User>>(content)!;
        }
        catch { }

        {
            _users = [];
        }

        return _users;   
    }

    public bool Save(UserRegistrationform form)
    {
        var user = UserFactory.Create(Form);
        _users.Add(user);

        var json = JsonSerializer.Serialize(_users);
        var result = _fileService.SaveContentToFile(json);
        return result;
    }
