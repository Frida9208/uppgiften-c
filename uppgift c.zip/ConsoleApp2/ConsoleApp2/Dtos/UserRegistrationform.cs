﻿namespace ConsoleApp2.Dtos
{
    public class UserRegistrationform;
    {
        public Guid Id { get; private set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string StreetAddress { get; set; }
        public string PostalCode { get; set; }
        public string City { get; set; }

        public Contact()
        {
            Id = Guid.NewGuid(); // Autogenerera ett unikt ID
        }

        public override string ToString()
        {
            return $"{Id}\n{FirstName} {LastName}\n{Email}\n{telefonnummer}\n{gatuadress}, \n{postkod}\n {stad}\n";
        }
    }

}
}
