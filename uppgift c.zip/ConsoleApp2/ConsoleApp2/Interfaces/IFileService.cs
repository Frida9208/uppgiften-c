﻿using ConsoleApp2.Dtos;

namespace ConsoleApp2.Interfaces;

public interface IFileService
{
    bool SaveContentToFile(string content);
    string GetContentFromfile();
}


public interface IUserService
    bool Save(UserRegistrationform form);

IEnumerable<User> GetAll();